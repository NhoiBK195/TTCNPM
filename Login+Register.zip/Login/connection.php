<?php
/**
 * Created by PhpStorm.
 * User: khang ho
 * Date: 4/13/2019
 * Time: 11:35 PM
 */

$server_username = "root";
$server_password = "";
$server_host = "localhost";
$database = 'test_data';

$conn = mysqli_connect($server_host,$server_username,$server_password,$database) or die("không thể kết nối tới database");
mysqli_query($conn,"SET NAMES 'UTF8'");
